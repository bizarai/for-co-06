# Enhanced Map Visualization with NLP - Cloudflare Deployment

This directory contains the static files needed to deploy the Enhanced Map Visualization with NLP application to Cloudflare Pages.

## Files Structure

- `index.html` - Main application HTML file
- `assets/` - Directory containing assets:
  - `styles.css` - CSS styling for the application
  - `enhanced-nlp-improved.js` - NLP processing logic
  - `visualization-integration.js` - Map visualization integration
  - `nlp-utils.js` - Utility functions for NLP processing
  - `app-init-fixed.js` - App initialization utilities

## Setup for Deployment

### 1. Mapbox Token

Before deploying to Cloudflare Pages, you need to set up your Mapbox token. Open the `index.html` file and replace `YOUR_MAPBOX_TOKEN` with your actual Mapbox public token:

```javascript
// For Cloudflare deployment - Configure mapbox token
const MAPBOX_PUBLIC_TOKEN = "YOUR_MAPBOX_TOKEN";
```

### 2. Deployment to Cloudflare Pages

1. **Log in to Cloudflare Dashboard**:
   - Go to the Cloudflare dashboard and select Pages from the sidebar.

2. **Create a New Project**:
   - Click "Create a project" and select "Connect to Git".
   - Connect your GitHub, GitLab, or Bitbucket account.
   - Select the repository where you've uploaded these files.

3. **Configure the Build**:
   - Set the build settings as follows:
     - Build command: Leave empty (no build required)
     - Build output directory: `/` (root)
     - Root directory: Set this to the directory containing these files

4. **Environment Variables** (Optional):
   - If you prefer not to hardcode your Mapbox token in the HTML file, you can add it as an environment variable:
     - Variable name: `MAPBOX_TOKEN`
     - Value: Your Mapbox public token

5. **Deploy**:
   - Click "Save and deploy".

### 3. Using Custom Domain (Optional)

After deployment, you can configure a custom domain for your application:

1. Go to the "Custom domains" tab in your Cloudflare Pages project.
2. Click "Set up a custom domain".
3. Follow the instructions to add your domain.

## Local Testing

To test locally before deploying:

1. You can use any local web server, such as:
   - Python's built-in server: `python -m http.server`
   - Node.js http-server: `npx http-server`

2. Open the application in your browser (typically at http://localhost:8000).

## Important Notes

- This is a client-side only version of the application. There's no backend server for processing API requests.
- Map visualization relies entirely on the Mapbox API with your provided token.
- NLP processing happens directly in the browser. 