/**
 * Cloudflare Pages Deployment Script
 * 
 * This script helps with deploying the application to Cloudflare Pages
 * using the Wrangler CLI. Before running this script, make sure you have
 * installed Wrangler: npm install -g wrangler
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// Configuration
const projectName = 'map-nlp-visualization';
const siteName = 'Map NLP Visualization';
const branch = 'main';

function executeCommand(command) {
  console.log(`Executing: ${command}`);
  try {
    const output = execSync(command, { encoding: 'utf8' });
    console.log(output);
    return output;
  } catch (error) {
    console.error(`Error executing command: ${command}`);
    console.error(error.stdout || error.message);
    throw error;
  }
}

function checkWranglerInstalled() {
  try {
    executeCommand('wrangler --version');
    return true;
  } catch (error) {
    return false;
  }
}

function loginToCloudflare() {
  try {
    // Check if already logged in
    executeCommand('wrangler whoami');
    console.log('Already logged in to Cloudflare');
  } catch (error) {
    console.log('Logging in to Cloudflare...');
    executeCommand('wrangler login');
  }
}

function deployToCloudflarePages() {
  console.log('Deploying to Cloudflare Pages...');
  
  // Check if wrangler is installed
  if (!checkWranglerInstalled()) {
    console.error('Wrangler CLI is not installed. Please install it with: npm install -g wrangler');
    process.exit(1);
  }
  
  // Login to Cloudflare if needed
  loginToCloudflare();
  
  // Check if the project exists
  let projectExists = false;
  try {
    const projectsOutput = executeCommand('wrangler pages project list');
    projectExists = projectsOutput.includes(projectName);
  } catch (error) {
    console.log('Could not check if project exists, assuming it does not');
  }
  
  if (!projectExists) {
    // Create a new project
    console.log(`Creating new project: ${projectName}`);
    executeCommand(`wrangler pages project create ${projectName} --production-branch=${branch}`);
  }
  
  // Deploy the project
  console.log('Deploying files to Cloudflare Pages...');
  executeCommand(`wrangler pages deploy . --project-name=${projectName} --branch=${branch}`);
  
  console.log('Deployment complete!');
  console.log('You can view your deployment at:');
  console.log(`https://${projectName}.pages.dev`);
}

// Run the deployment
deployToCloudflarePages(); 