# Enhanced Map Visualization with NLP - Cloudflare Deployment

This directory contains the static files needed to deploy the Enhanced Map Visualization with NLP application to Cloudflare Pages.

## Files Structure

- `index.html` - Main application HTML file
- `assets/` - Directory containing assets:
  - `styles.css` - CSS styling for the application
  - `enhanced-nlp-improved.js` - NLP processing logic
  - `visualization-integration.js` - Map visualization integration
  - `nlp-utils.js` - Utility functions for NLP processing
  - `app-init-fixed.js` - App initialization utilities
- `deploy.js` - Deployment script for Cloudflare Pages using Wrangler
- `package.json` - Contains scripts for easy deployment
- `test.html` - Page to test if modules load correctly

## Deployment Methods

There are two ways to deploy this application to Cloudflare Pages:

### Method 1: Using Cloudflare Dashboard (Manual)

1. **Log in to Cloudflare Dashboard**:
   - Go to the Cloudflare dashboard and select Pages from the sidebar.

2. **Create a New Project**:
   - Click "Create a project" and select "Connect to Git".
   - Connect your GitHub, GitLab, or Bitbucket account.
   - Select the repository where you've uploaded these files.

3. **Configure the Build**:
   - Set the build settings as follows:
     - Build command: Leave empty (no build required)
     - Build output directory: `/` (root)
     - Root directory: Set this to the directory containing these files

4. **Environment Variables** (Optional):
   - If you prefer not to hardcode your Mapbox token in the HTML file, you can add it as an environment variable:
     - Variable name: `MAPBOX_TOKEN`
     - Value: Your Mapbox public token

5. **Deploy**:
   - Click "Save and deploy".

### Method 2: Using Wrangler CLI (Automated)

This repository includes a deployment script that uses Cloudflare's Wrangler CLI to deploy the application directly from your local environment.

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Install Wrangler** (if not already installed):
   ```bash
   npm run install-wrangler
   ```

3. **Deploy to Cloudflare Pages**:
   ```bash
   npm run deploy
   ```

   This script will:
   - Check if Wrangler is installed
   - Log in to Cloudflare (if not already logged in)
   - Create a new Pages project (if it doesn't exist)
   - Deploy the files to Cloudflare Pages

4. **View Your Deployment**:
   - After successful deployment, your site will be available at:
   - `https://map-nlp-visualization.pages.dev`

## Local Testing

To test locally before deploying:

1. Run the local server:
   ```bash
   npm start
   ```

2. Open the application in your browser at http://localhost:3000

3. Test importing modules by accessing:
   - http://localhost:3000/test.html

## Important Notes

- This is a client-side only version of the application. There's no backend server for processing API requests.
- Map visualization relies entirely on the Mapbox API with your provided token.
- NLP processing happens directly in the browser.
- The Mapbox token is already set in the index.html file for convenience, but should be replaced with your own token for production use. 