# Map Visualization Deployment

This is the optimized comparison version of the map visualization application (follow-up to `for-co-04`).

## Features

- Improved geocoding with caching and fallbacks
- Optimized route visualization
- Parallel processing for faster performance
- Enhanced error handling and user feedback
- Various performance optimizations

## Deployment Notes

This application is deployed on Cloudflare Pages. It's a static site that uses Mapbox API for map visualization.

The API endpoints are proxied through the Cloudflare Pages Functions (previously through a Node.js server).

## Local Development

To run this project locally, start a simple HTTP server in this directory:

```bash
npx http-server
```

Or use any static file server of your choice. 