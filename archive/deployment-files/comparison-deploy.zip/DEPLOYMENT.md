# Deployment Instructions for Cloudflare Pages

This document explains how to deploy the optimized comparison version to Cloudflare Pages.

## Prerequisites

1. A Cloudflare account
2. A Mapbox API token (must be a public token that can be used in browser environments)

## Deployment Steps

### Option 1: Using the Cloudflare Dashboard

1. Go to the [Cloudflare Dashboard](https://dash.cloudflare.com/)
2. Navigate to "Pages"
3. Click "Create a project" → "Upload assets"
4. Drag and drop the contents of this directory or the `deployment.zip` file (created by running `./deploy.sh`)
5. Set up your project with the name "for-co-06" or another name of your choice
6. In the project settings, add an environment variable:
   - Name: `MAPBOX_TOKEN`
   - Value: Your Mapbox API public token

### Option 2: Using Wrangler CLI

1. Install Wrangler CLI if not already installed:
   ```bash
   npm install -g wrangler
   ```

2. Log in to your Cloudflare account:
   ```bash
   wrangler login
   ```

3. Deploy the site:
   ```bash
   cd comparison-deploy
   wrangler pages deploy .
   ```

4. After deployment, go to the Cloudflare Dashboard → Pages → Your Project → Settings → Environment variables
5. Add the `MAPBOX_TOKEN` environment variable with your Mapbox API token as the value

## Verifying the Deployment

1. Visit your deployed site (URL will be shown after deployment)
2. Try a route query like "Route from New York to Los Angeles"
3. Verify that the map visualization works correctly

## Troubleshooting

If the map doesn't load:
- Check the browser console for errors
- Verify that your Mapbox token is set correctly
- Ensure that the Mapbox token has the necessary permissions

If API requests fail:
- Check that the Functions are deployed correctly
- Verify URL paths in the browser console
- Check Cloudflare Functions logs in the dashboard 