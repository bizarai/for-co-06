#!/bin/bash

# Deployment script for Cloudflare Pages

echo "🚀 Starting deployment to Cloudflare Pages..."

# Check if wrangler is installed
if ! command -v wrangler &> /dev/null; then
    echo "❌ Wrangler CLI not found. Installing..."
    npm install -g wrangler
fi

# Make sure the script is executable
chmod +x deploy.sh

# Create a zip file for deployment
echo "📦 Creating deployment package..."
zip -r deployment.zip . -x "*.git*" -x "node_modules/*" -x "deploy.sh" -x "deployment.zip"

echo "✅ Deployment package created: deployment.zip"
echo ""
echo "To deploy to Cloudflare Pages:"
echo "1. Go to https://dash.cloudflare.com/"
echo "2. Select 'Pages'"
echo "3. Create a new project or select an existing one"
echo "4. Upload the deployment.zip file"
echo ""
echo "Alternatively, run the following command to deploy using Wrangler CLI:"
echo "wrangler pages deploy ."
echo ""
echo "Don't forget to set the MAPBOX_TOKEN environment variable in Cloudflare Pages settings!" 