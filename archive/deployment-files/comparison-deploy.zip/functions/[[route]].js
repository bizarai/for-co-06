// This file is used to handle any routes that aren't explicitly defined
// It helps with Cloudflare Pages Functions routing

export async function onRequest(context) {
  const url = new URL(context.request.url);
  const path = url.pathname;
  
  console.log(`Request received for path: ${path}`);
  
  // Return a 404 for any paths that we don't explicitly handle
  return new Response(
    JSON.stringify({ error: "Not Found", path: path }),
    {
      status: 404,
      headers: { "Content-Type": "application/json" },
    }
  );
} 