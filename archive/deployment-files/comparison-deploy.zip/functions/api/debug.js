// Cloudflare Function for debugging
export async function onRequest(context) {
  try {
    // Get basic environment info
    const info = {
      timestamp: new Date().toISOString(),
      environment: "Cloudflare Pages",
      runtimeVersion: "Cloudflare Workers",
      api: "Working correctly"
    };
    
    return new Response(
      JSON.stringify(info, null, 2),
      {
        headers: { 
          "Content-Type": "application/json",
          "Cache-Control": "no-store, max-age=0",
        },
      }
    );
  } catch (error) {
    console.error("Debug API error:", error);
    
    return new Response(
      JSON.stringify({ error: "Debug endpoint error", details: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      }
    );
  }
} 