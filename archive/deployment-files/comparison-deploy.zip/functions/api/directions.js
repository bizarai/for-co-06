// Cloudflare Function to proxy Mapbox Directions API requests
export async function onRequest(context) {
  const MAPBOX_TOKEN = context.env.MAPBOX_TOKEN || "YOUR_MAPBOX_TOKEN";
  
  try {
    // Get query parameters
    const url = new URL(context.request.url);
    const coordinates = url.searchParams.get("coordinates");
    const profile = url.searchParams.get("profile") || "mapbox/driving";
    
    if (!coordinates) {
      return new Response(
        JSON.stringify({ error: "Missing coordinates parameter" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json" },
        }
      );
    }
    
    // Construct the Mapbox Directions API URL
    const mapboxUrl = `https://api.mapbox.com/directions/v5/${profile}/${coordinates}?geometries=geojson&access_token=${MAPBOX_TOKEN}`;
    
    // Fetch from Mapbox
    const response = await fetch(mapboxUrl);
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`Mapbox API error (${response.status}): ${errorText}`);
      
      return new Response(
        JSON.stringify({ 
          error: `Mapbox API returned ${response.status}`, 
          details: errorText 
        }),
        {
          status: response.status,
          headers: { "Content-Type": "application/json" },
        }
      );
    }
    
    // Return the directions data
    const data = await response.json();
    
    return new Response(
      JSON.stringify(data),
      {
        headers: { 
          "Content-Type": "application/json",
          "Cache-Control": "public, max-age=3600", // Cache for 1 hour
        },
      }
    );
  } catch (error) {
    console.error("Error fetching directions:", error);
    
    return new Response(
      JSON.stringify({ error: "Failed to get directions", details: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      }
    );
  }
} 