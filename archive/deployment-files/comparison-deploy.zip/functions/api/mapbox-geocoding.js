// Cloudflare Function to proxy Mapbox Geocoding API requests
export async function onRequest(context) {
  const MAPBOX_TOKEN = context.env.MAPBOX_TOKEN || "YOUR_MAPBOX_TOKEN";
  
  try {
    // Get query parameters
    const url = new URL(context.request.url);
    const query = url.searchParams.get("q");
    
    if (!query) {
      return new Response(
        JSON.stringify({ error: "Missing query parameter" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json" },
        }
      );
    }
    
    // Construct the Mapbox Geocoding API URL
    const mapboxUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(query)}.json?access_token=${MAPBOX_TOKEN}&limit=1`;
    
    // Fetch from Mapbox
    const response = await fetch(mapboxUrl);
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`Mapbox Geocoding API error (${response.status}): ${errorText}`);
      
      return new Response(
        JSON.stringify({ 
          error: `Mapbox Geocoding API returned ${response.status}`, 
          details: errorText 
        }),
        {
          status: response.status,
          headers: { "Content-Type": "application/json" },
        }
      );
    }
    
    // Return the geocoding data
    const data = await response.json();
    
    return new Response(
      JSON.stringify(data),
      {
        headers: { 
          "Content-Type": "application/json",
          "Cache-Control": "public, max-age=86400", // Cache for 24 hours
        },
      }
    );
  } catch (error) {
    console.error("Error in geocoding:", error);
    
    return new Response(
      JSON.stringify({ error: "Failed to geocode location", details: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      }
    );
  }
} 