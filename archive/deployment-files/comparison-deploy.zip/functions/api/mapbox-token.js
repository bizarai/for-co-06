// Cloudflare Function to provide the Mapbox token
export async function onRequest(context) {
  // This would ideally be set as a Cloudflare environment variable
  // For now, we're using a placeholder - you'll need to configure this in Cloudflare
  const MAPBOX_TOKEN = context.env.MAPBOX_TOKEN || "YOUR_MAPBOX_TOKEN";
  
  try {
    return new Response(
      JSON.stringify({ token: MAPBOX_TOKEN }),
      {
        headers: {
          "Content-Type": "application/json",
          "Cache-Control": "no-store, max-age=0",
        },
      }
    );
  } catch (error) {
    console.error("Error serving Mapbox token:", error);
    return new Response(
      JSON.stringify({ error: "Failed to get token" }),
      {
        status: 500,
        headers: { "Content-Type": "application/json" },
      }
    );
  }
} 